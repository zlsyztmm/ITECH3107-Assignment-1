package au.edu.federation.itech3107.studentattendance30395696.jiekou;

import au.edu.federation.itech3107.studentattendance30395696.entity.Course;

public interface CallBack {
    void doSomeThing(Course course);
}
